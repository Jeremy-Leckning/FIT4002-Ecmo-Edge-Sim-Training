const AWS = require("aws-sdk");

const dynamo = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event, context) => {
  let body;
  let statusCode = 200;
  const headers = {
    "Content-Type": "application/json"
  };

  var ecmo_dynamo_textbook_table_name = "ecmo-api-dev-textbook-dynamo-table";
  var ecmo_dynamo_scenario_table_name = "ecmo-api-dev-scenario-dynamo-table";

  try {
    switch (event.routeKey) {
      /* [TEXTBOOK] CREATE chapter(s)
       * https://docs.aws.amazon.com/AWSJavaScriptSDK/latest/AWS/DynamoDB.html#putItem-property
       */
      case "PUT /textbook/chapters":
        let putTextbookChapterJSON = JSON.parse(event.body);
        await dynamo
          .put({
            TableName: ecmo_dynamo_textbook_table_name,
            Item: {
              id: putTextbookChapterJSON.id,
              chapter_number: putTextbookChapterJSON.chapter_number,
              chapter_title: putTextbookChapterJSON.chapter_title,
              object_type : "chapter"
            }
          })
          .promise();
        body = `chapter created | 
                ${putTextbookChapterJSON}`;
        break;
      /* [TEXTBOOK] READ chapter(s)
       * https://docs.aws.amazon.com/AWSJavaScriptSDK/latest/AWS/DynamoDB.html#getItem-property
       */
      case "GET /textbook/chapters/{id}":
        body = await dynamo
          .get({
            TableName: ecmo_dynamo_textbook_table_name,
            Key: {
              id: event.pathParameters.id
            }
          }).promise()
        break;
      /* [TEXTBOOK] UPDATE chapter(s)
       * https://docs.aws.amazon.com/AWSJavaScriptSDK/latest/AWS/DynamoDB.html#updateItem-property
       */
      case "POST /textbook/chapters":
        let postTextbookChapterJSON = JSON.parse(event.body);
        await dynamo
          .updateItem({
            TableName: ecmo_dynamo_textbook_table_name,
            Item: {
              id: postTextbookChapterJSON.id,
              chapter_number: postTextbookChapterJSON.chapter_number,
              chapter_title: postTextbookChapterJSON.chapter_title,
              object_type : "chapter"
            }
          })
          .promise();
        body = `chapter updated | 
                ${postTextbookChapterJSON}`;
        break;
      /* [TEXTBOOK] DESTROY chapter(s)
       * https://docs.aws.amazon.com/AWSJavaScriptSDK/latest/AWS/DynamoDB.html#deleteItem-property
       */
      case "DELETE /textbook/chapters/{id}":
        body = await dynamo
          .delete({
            TableName: ecmo_dynamo_textbook_table_name,
            Key: {
              id: event.pathParameters.id
            }
          })
        break;
      /* [TEXTBOOK] LIST chapter(s)
       * https://docs.aws.amazon.com/AWSJavaScriptSDK/latest/AWS/DynamoDB.html#deleteItem-property
       */
      case "GET /textbook/chapters":
        body = await dynamo
          .scan({ 
            TableName: ecmo_dynamo_textbook_table_name,
            FilterExpression: "object_type = chapter" 
          }).promise()
        break;
      
      /* [TEXTBOOK] CREATE page(s)
       * https://docs.aws.amazon.com/AWSJavaScriptSDK/latest/AWS/DynamoDB.html#putItem-property
       */
      case "PUT /textbook/pages":
        let putTextbookPageJSON = JSON.parse(event.body);
        await dynamo
          .put({
            TableName: ecmo_dynamo_textbook_table_name,
            Item: {
              id: putTextbookPageJSON.id,
              chapter_number: putTextbookPageJSON.chapter_number,
              chapter_title: putTextbookPageJSON.chapter_title,
              object_type: "page",
              header_content: putTextbookPageJSON.header_content,
              subheader_content: putTextbookPageJSON.subheader_content,
              left_content: putTextbookPageJSON.left_content,
              right_content: putTextbookPageJSON.right_content,
              img_src_content_top_right: putTextbookPageJSON.img_src_content_top_right,
              img_src_content_bottom_right: putTextbookPageJSON.img_src_content_bottom_right,
              img_src_content_top_left: putTextbookPageJSON.img_src_content_top_left,
              img_src_content_bottom_right: putTextbookPageJSON.img_src_content_bottom_right,
              img_header_content_top_right: putTextbookPageJSON.img_header_content_top_right,
              img_header_content_bottom_right: putTextbookPageJSON.img_header_content_bottom_right,
              img_header_content_top_left: putTextbookPageJSON.img_header_content_top_left,
              img_header_content_bottom_right: putTextbookPageJSON.img_header_content_bottom_right,
              config_left_width: putTextbookPageJSON.config_left_width,
              config_right_width: putTextbookPageJSON.config_right_width,
              config_mirrored_view: putTextbookPageJSON.config_mirrored_view,
              config_completed: putTextbookPageJSON.config_completed
            }
          })
          .promise();
        body = `page created | 
                ${putTextbookPageJSON}`;
        break;
      /* [TEXTBOOK] READ page(s)
      * https://docs.aws.amazon.com/AWSJavaScriptSDK/latest/AWS/DynamoDB.html#getItem-property
      */
      case "GET /textbook/pages/{id}":
        body = await dynamo
          .get({
            TableName: ecmo_dynamo_textbook_table_name,
            Key: {
              id: event.pathParameters.id
            }
          }).promise()
        break;
      /* [TEXTBOOK] UPDATE page(s)
      * https://docs.aws.amazon.com/AWSJavaScriptSDK/latest/AWS/DynamoDB.html#updateItem-property
      */
      case "POST /textbook/pages":
        let postTextbookPageJSON = JSON.parse(event.body);
        await dynamo
          .updateItem({
            TableName: ecmo_dynamo_textbook_table_name,
            Item: {
              id: postTextbookPageJSON.id,
              chapter_number: postTextbookPageJSON.chapter_number,
              chapter_title: postTextbookPageJSON.chapter_title,
              object_type: "page",
              header_content: postTextbookPageJSON.header_content,
              subheader_content: postTextbookPageJSON.subheader_content,
              left_content: postTextbookPageJSON.left_content,
              right_content: postTextbookPageJSON.right_content,
              img_src_content_top_right: postTextbookPageJSON.img_src_content_top_right,
              img_src_content_bottom_right: postTextbookPageJSON.img_src_content_bottom_right,
              img_src_content_top_left: postTextbookPageJSON.img_src_content_top_left,
              img_src_content_bottom_right: postTextbookPageJSON.img_src_content_bottom_right,
              img_header_content_top_right: postTextbookPageJSON.img_header_content_top_right,
              img_header_content_bottom_right: postTextbookPageJSON.img_header_content_bottom_right,
              img_header_content_top_left: postTextbookPageJSON.img_header_content_top_left,
              img_header_content_bottom_right: postTextbookPageJSON.img_header_content_bottom_right,
              config_left_width: postTextbookPageJSON.config_left_width,
              config_right_width: postTextbookPageJSON.config_right_width,
              config_mirrored_view: postTextbookPageJSON.config_mirrored_view,
              config_completed: postTextbookPageJSON.config_completed
            }
          })
          .promise();
        body = `page updated | 
                ${postTextbookPageJSON}`;
        break;
      /* [TEXTBOOK] DESTROY page(s)
      * https://docs.aws.amazon.com/AWSJavaScriptSDK/latest/AWS/DynamoDB.html#deleteItem-property
      */
      case "DELETE /textbook/pages/{id}":
        await dynamo
          .delete({
            TableName: ecmo_dynamo_textbook_table_name,
            Key: {
              id: event.pathParameters.id
            }
          })
          .promise();
        body = `deleted page ${event.pathParameters.id}`;
        break;
      /* [TEXTBOOK] LIST page(s)
      * https://docs.aws.amazon.com/AWSJavaScriptSDK/latest/AWS/DynamoDB.html#deleteItem-property
      */
      case "GET /textbook/pages":
        body = await dynamo
          .scan({ 
            TableName: ecmo_dynamo_textbook_table_name,
            FilterExpression: "object_type = pages" 
          }).promise()
        break;

      /* [TEXTBOOK] CREATE scenario(s)
      * https://docs.aws.amazon.com/AWSJavaScriptSDK/latest/AWS/DynamoDB.html#putItem-property
      */
      case "PUT /scenario":
        let putScenarioJSON = JSON.parse(event.body);
        await dynamo
          .put({
            TableName: ecmo_dynamo_scenario_table_name,
            Item: putScenarioJSON
          })
          .promise();
        body = `put scenario |
                ${putScenarioJSON}`;
        break;
      /* [TEXTBOOK] READ scenario(s)
      * https://docs.aws.amazon.com/AWSJavaScriptSDK/latest/AWS/DynamoDB.html#getItem-property
      */
      case "GET /scenario/{id}":
        body = await dynamo
          .get({
            TableName: ecmo_dynamo_scenario_table_name,
            Key: {
              id: event.pathParameters.id
            }
          }).promise()
        break;
      /* [TEXTBOOK] UPDATE scenario(s)
      * https://docs.aws.amazon.com/AWSJavaScriptSDK/latest/AWS/DynamoDB.html#updateItem-property
      */
      case "POST /scenario":
        let postScenarioJSON = JSON.parse(event.body);
        await dynamo
          .updateItem({
            TableName: ecmo_dynamo_scenario_table_name,
            Item: postScenarioJSON
          })
          .promise();
          body = `scenario updated |
          ${postScenarioJSON}`;
        break;
      /* [TEXTBOOK] DESTROY scenario(s)
      * https://docs.aws.amazon.com/AWSJavaScriptSDK/latest/AWS/DynamoDB.html#deleteItem-property
      */
      case "DELETE /scenario/{id}":
        await dynamo
          .delete({
            TableName: ecmo_dynamo_scenario_table_name,
            Key: {
              id: event.pathParameters.id
            }
          })
          .promise();
        body = `deleted scenario ${event.pathParameters.id}`;
        break;
      /* [TEXTBOOK] LIST scenario(s)
      * https://docs.aws.amazon.com/AWSJavaScriptSDK/latest/AWS/DynamoDB.html#deleteItem-property
      */
      case "GET /scenario":
        body = await dynamo
          .scan({ 
            TableName: ecmo_dynamo_scenario_table_name,
          }).promise()
        break;  
      default:
        throw new Error(`Unsupported route: "${event.routeKey}"`);
    }
  } catch (err) {
    statusCode = 400;
    body = err.message;
  } finally {
    body = JSON.stringify(body);
  }

  return {
    statusCode,
    body,
    headers
  };
};
