const AWS = require("aws-sdk");

const dynamo = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event, context) => {
  let body;
  let statusCode = 200;
  const headers = {
    "Content-Type": "application/json"
  };

  try {
    switch (event.routeKey) {
      case "DELETE /chapters/{id}":
        await dynamo
          .delete({
            TableName: "ecmo_poc",
            Key: {
              id: event.pathParameters.id
            }
          })
          .promise();
        body = `Deleted chapter ${event.pathParameters.id}`;
        break;
      case "GET /chapters/{id}":
        body = await dynamo
          .get({
            TableName: "ecmo_poc",
            Key: {
              id: event.pathParameters.id
            }
          })
          .promise();
        break;
      case "GET /chapters":
        body = await dynamo.scan({ TableName: "ecmo_poc" }).promise();
        break;
      case "PUT /chapters":
        let requestJSON = JSON.parse(event.body);
        await dynamo
          .put({
            TableName: "ecmo_poc",
            Item: {
              id: requestJSON.id,
              chapter_number: requestJSON.price,
              name: requestJSON.name
            }
          })
          .promise();
        body = `Put item ${requestJSON.id}`;
        break;
      case "PUT /vitals":
        let vitalsJSON = JSON.parse(event.body);
        await dynamo
          .put({
            TableName: "ecmo_vitals",
            Item: {
              user_id: vitalsJSON.user_id,
              simulation_time: vitalsJSON.simulation_time,
              systolic_bp: vitalsJSON.systolic_bp,
              mean_arterial_bp: vitalsJSON.mean_arterial_bp,
	            diastolic_bp: vitalsJSON.diastolic_bp,
	            spo2: vitalsJSON.spo2,
	            core_temperature: vitalsJSON.core_temperature,
            	pulse_rate: vitalsJSON.pulse_rate,
            	etco2: vitalsJSON.etco2, 
            	respiration_rate: vitalsJSON.respiration_rate,
            	ecg_mV: vitalsJSON.ecg_mV
            }
          })
          .promise();
        body = `Put item ${vitalsJSON.user_id}, ${vitalsJSON.simulation_time}`;
        break;
      // case "GET /vitals/{id}":
      //   console.log(event);
      //   body = await dynamo
      //     .get({
      //       TableName: "ecmo_vitals",
      //       Key: {
      //         user_id: event.pathParameters.id,
      //         // simulation_time: event.pathParameters.time
      //       }
      //     })
      //     .promise();
      //   break;
      case "GET /vitals/{id}/{time}":
        console.log(event.pathParameters)
        body = await dynamo
          .get({
            TableName: "ecmo_vitals",
            Key: {
              user_id: event.pathParameters.id,
              simulation_time: event.pathParameters.time
            }
          })
          .promise();
        break;
      default:
        throw new Error(`Unsupported route: "${event.routeKey}"`);
    }
  } catch (err) {
    statusCode = 400;
    body = err.message;
  } finally {
    body = JSON.stringify(body);
  }

  return {
    statusCode,
    body,
    headers
  };
};
